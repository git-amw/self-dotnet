﻿using System.ComponentModel.DataAnnotations;

namespace Amardeep_Assignment.Models
{
    public class TestModel
    {
        [Key]
        public int Id { get; set; }

        public string Name { get; set; }

        public string Description { get; set; }

        public int Amount { get; set; }


    }
}
