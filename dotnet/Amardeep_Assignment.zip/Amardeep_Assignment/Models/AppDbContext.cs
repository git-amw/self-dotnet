﻿using Microsoft.EntityFrameworkCore;

namespace Amardeep_Assignment.Models
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> option) : base(option)
        {
            
        }

        public DbSet<TestModel> Models { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<TestModel>().HasData(new TestModel
            {
                Id = 1,
                Name = "1Test",
                Description = "1Test",
                Amount = 1,
            });

            modelBuilder.Entity<TestModel>().HasData(new TestModel
            {
                Id = 2,
                Name = "2Test",
                Description = "2Test",
                Amount = 2,
            });

            modelBuilder.Entity<TestModel>().HasData(new TestModel
            {
                Id = 3,
                Name = "3Test",
                Description = "3Test",
                Amount = 3,
            });

            modelBuilder.Entity<TestModel>().HasData(new TestModel
            {
                Id = 4,
                Name = "4Test",
                Description = "4Test",
                Amount = 4,
            });
        }
    }


}
