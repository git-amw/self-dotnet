﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Amardeep_Assignment.Migrations
{
    public partial class first : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
