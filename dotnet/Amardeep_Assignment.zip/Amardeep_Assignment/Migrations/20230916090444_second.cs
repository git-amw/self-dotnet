﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Amardeep_Assignment.Migrations
{
    public partial class second : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Models",
                columns: table => new
                {
                    Id = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    Name = table.Column<string>(type: "TEXT", nullable: false),
                    Description = table.Column<string>(type: "TEXT", nullable: false),
                    Amount = table.Column<int>(type: "INTEGER", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Models", x => x.Id);
                });

            migrationBuilder.InsertData(
                table: "Models",
                columns: new[] { "Id", "Amount", "Description", "Name" },
                values: new object[] { 1, 1, "1Test", "1Test" });

            migrationBuilder.InsertData(
                table: "Models",
                columns: new[] { "Id", "Amount", "Description", "Name" },
                values: new object[] { 2, 2, "2Test", "2Test" });

            migrationBuilder.InsertData(
                table: "Models",
                columns: new[] { "Id", "Amount", "Description", "Name" },
                values: new object[] { 3, 3, "3Test", "3Test" });

            migrationBuilder.InsertData(
                table: "Models",
                columns: new[] { "Id", "Amount", "Description", "Name" },
                values: new object[] { 4, 4, "4Test", "4Test" });

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Models");
        }
    }
}
